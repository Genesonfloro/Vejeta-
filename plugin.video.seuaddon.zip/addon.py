import sys
import xbmcaddon
import xbmcplugin
import xbmcgui

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])

def listar_videos():
    videos = [
        {"name": "Anime 1", "url": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"},
        {"name": "Filme 1", "url": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"},
    ]

    for video in videos:
        list_item = xbmcgui.ListItem(label=video["name"])
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=video["url"], listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    listar_videos()
